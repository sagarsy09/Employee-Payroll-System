import java.security.PrivateKey;

public class Employee {
    private String name;
    private int id;

    
}
