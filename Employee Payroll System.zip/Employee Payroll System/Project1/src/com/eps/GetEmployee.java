package com.eps;

import java.sql.*;
import java.util.List;

public class GetEmployee {

    private Connection connection; // Assuming this is initialized elsewhere
    private List<Employee> empList; // Assuming this is initialized elsewhere

    public void GetEmployee() {
        String selectQuery = "SELECT * FROM employees";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(selectQuery);
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String type = rs.getString("type");
                double salary = rs.getDouble("salary");

                if (type.equals("FullTime")) {
                    FullTimeEmployee fullTimeEmployee = new FullTimeEmployee(name, id, salary);
                    empList.add(fullTimeEmployee);
                } else if (type.equals("PartTime")) {
                    int hoursWorked = rs.getInt("hoursWorked");
                    double hourlyRate = rs.getDouble("hourlyRate");
                    PartTimeEmployee partTimeEmployee = new PartTimeEmployee(name, id, hoursWorked, hourlyRate);
                    empList.add(partTimeEmployee);
                }
            }
            System.out.println("Employees loaded from database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
