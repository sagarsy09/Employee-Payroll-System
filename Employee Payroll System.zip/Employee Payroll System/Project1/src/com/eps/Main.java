package com.eps;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Initialize the PayrollSystem
        PayrollSystem payrollSystem = new PayrollSystem();

        // Create FullTimeEmployee and PartTimeEmployee objects
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("John Doe", 101, 6000);
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Jane Smith", 102, 20, 25.5);

        // Add employees to the payroll system and save them to the database
        payrollSystem.addEmployee(fullTimeEmployee);
        payrollSystem.addEmployee(partTimeEmployee);

        // Display all employees in the payroll system
        System.out.println("Employees in the system:");
        payrollSystem.displayEmployees();

        // Initialize GetEmployee to fetch employees from the database
        GetEmployee getEmployee = new GetEmployee();

        // Assuming you have a way to initialize the connection and employee list in GetEmployee
        getEmployee.setConnection(DatabaseConnection.getConnection());
        getEmployee.setEmpList(payrollSystem.getEmpList()); // Pass the list to get populated

        // Fetch employees from the database
        getEmployee.getEmployees();

        // Display the fetched employees
        System.out.println("Employees fetched from the database:");
        for (Employee emp : getEmployee.getEmpList()) {
            System.out.println(emp);
        }
    }
}
