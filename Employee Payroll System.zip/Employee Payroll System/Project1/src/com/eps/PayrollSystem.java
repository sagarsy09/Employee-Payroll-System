package com.eps;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class PayrollSystem {
	ArrayList<Employee> empList ;
	private Connection connection;
	
	public PayrollSystem() {
		empList = new ArrayList<Employee>();
		connection = DatabaseConnection.getConnection();
	}
	
	public void addEmployee(Employee employee) {
		empList.add(employee);
		saveEmployeeToDB(employee);
	}
	
	
	public void saveEmployeeToDB(Employee employee) {
		String insertQuery = "insert into employee (id , name , type , salary , hoursWorked , hourlyRate) values (? , ? , ? , ? , ? , ?)";
		
		try {
			PreparedStatement ps = connection.prepareStatement(insertQuery);
			
			ps.setInt(1, employee.getId());
			ps.setString(2, employee.getName());
			
			if(employee instanceof FullTimeEmployee) {
				ps.setString(3, "FullTime");
				ps.setDouble(4, ((FullTimeEmployee)employee).calculateSalary());
				ps.setNull(5, java.sql.Types.INTEGER);
				ps.setNull(6 , java.sql.Types.DATALINK);
			}
			else if(employee instanceof PartTimeEmployee) {
				ps.setString(3, "PartTime");
				ps.setDouble(4, ((PartTimeEmployee)employee).calculateSalary());
				ps.setInt(5, ((PartTimeEmployee) employee).getHoursWorked());
				ps.setDouble(6, ((PartTimeEmployee) employee).getHourlyRate());
			}
			
			ps.execute();
			
			System.out.println("Employee Saved to database!");
			
		}
		catch (Exception e) {
			e.printStackTrace();// TODO: handle exception
		}
	}
	
	
}
