/**
 * 
 */
/**
 * 
 */
module Project1 {
	requires java.sql;
}